#to get started with first get the application config file.
wget https://raw.githubusercontent.com/jhipster/jhipster-sample-app/master/src/main/resources/config/application-prod.yml

#Download yq package on linux box using below
sudo add-apt-repository ppa:rmescandon/yq
sudo apt-get install yq

#Some info about yq  
yq is a command line tool that will help you handle your YAML resources better
yq can take a YAML file as an input and do the following:

Read values from the file.
Add new values.
Update Existing values.
Generate new YAML files.
Convert YAML into JSON.
Merge two or more YAML files.

#Steps to replicate
Once yq utility is installed on the linux box, please execute "updateYamlConfig.sh" and provide Key and value as parameters
Eg: updateYamlConfig.sh spring.devtools.enabled true
    updateYamlConfig.sh spring.mail.port 443
once executing script "updateYamlConfig.sh" observe application-prod.yml file to validate the modified changes.

